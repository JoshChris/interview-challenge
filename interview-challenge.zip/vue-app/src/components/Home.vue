<template>
    <div>Choose a dog to display a picture</div>
</template>